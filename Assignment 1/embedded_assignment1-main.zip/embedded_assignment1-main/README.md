This repo contains the assessment 1 files that represents a simple program to do some operations on a given array.
Author: Supratim Majumder
